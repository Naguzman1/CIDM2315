﻿namespace Homework9;
using System.Linq;
class Program
{
    static void Main(string[] args)
    {
        //int[] int_1d_array = {111,222,333,444};
        //string[] name = {"Alice", "Bob", "Cathy", "David"};
        //ArraySort(int_1d_array,name);

        string stu1 = "Alice";
        string stu2 = "Bob";
        string stu3 = "Cathy";
        string stu4 = "David";
        
        int stu1_ID = 111;
        int stu2_ID = 222;
        int stu3_ID = 333;
        int stu4_ID = 444;

        var gradebook = new Dictionary<string, double>(){
            {"Alice", 4.0},{"Bob", 3.6},{"Cathy", 2.5},{"David",1.8}
        };

        if (gradebook.ContainsKey("Tom")){
        
        }
        else{gradebook.Add("Tom", 3.3);}

        double avg_GPA = (gradebook["Alice"] + gradebook["Bob"] + gradebook["Cathy"] + gradebook["David"] + gradebook["Tom"]) / 5;

        Console.WriteLine("The average GPA is: " + avg_GPA);

        if(gradebook["Alice"] > avg_GPA){
            Console.WriteLine($"Student ID: {stu1_ID}, Student Name: Alice");
        }
        if(gradebook["Bob"] > avg_GPA){
            Console.WriteLine($"Student ID: {stu2_ID}, Student Name: Bob");
        }
        if(gradebook["Cathy"] > avg_GPA){
            Console.WriteLine($"Student ID: {stu3_ID}, Student Name: Cathy");
        }
        if(gradebook["David"] > avg_GPA){
            Console.WriteLine($"Student ID: {stu4_ID}, Student Name: David");
        }
        if(gradebook["Tom"] > avg_GPA){
            Console.WriteLine("Student ID: 555, Student Name: Tom");
        }
    }
    
//     static void ArraySort(int[] int_1d_array, string[] name){
//         Console.WriteLine("--------Original array-----");
//         foreach(var val in int_1d_array){
//             Console.Write(val + " ");
//         }
//     Array.Sort(int_1d_array);

//     Console.WriteLine("\nSorted int_1d_array: ");
//     foreach(var val in int_1d_array){
//             Console.Write(val + " ");
//         }

//         Console.WriteLine("\n-------- ");
//         Console.WriteLine("Original order of name array; ");
//     foreach(var val in name){
//             Console.Write(val + " ");
//         }
//         Array.Sort(name);
//         Console.WriteLine("\nSorted name array: ");
//         foreach(var val in name){
//             Console.Write(val+" ");
//         }
// }
}