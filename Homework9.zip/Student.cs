class Student{
  private int studentID;
  private string studentName;
  public int cus_age;


  public void PrintInfo(int studentID, string studentName){
    Console.WriteLine(studentID + " " + studentName);
    
  }
  

  
}