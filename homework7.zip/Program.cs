﻿namespace Homework7;
class Program
{
    public static void Main(string[] args) {
    Customer c1 = new Customer(110, "Alice", 28);
  
    Customer c2 = new Customer(111, "Bob", 30);
    
    c1.PrintCusInfo();
    c2.PrintCusInfo();

    c1.ChangeID(220);
    c2.ChangeID(221);

    c1.PrintCusInfo();
    c2.PrintCusInfo();

    if( c1.cus_age > c2.cus_age){
        Console.WriteLine("Alice is older");
    }
    else{
        Console.WriteLine("Bob is older");
    }
  }
}